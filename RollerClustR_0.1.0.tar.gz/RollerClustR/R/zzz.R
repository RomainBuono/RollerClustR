# =============================================================================
# IMPORTS GLOBAUX POUR LE PACKAGE
# =============================================================================

#' @importFrom grDevices colorRampPalette
#' @importFrom graphics abline legend
#' @importFrom stats as.dendrogram as.dist heatmap rect.hclust sd cor cutree hclust
#' @importFrom utils write.csv
NULL
