## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(RollerClustR)

## ----basic_usage--------------------------------------------------------------
# Charger les données iris
data(iris)

# Clustering avec VAR_CAH
result <- roller_clust(
  X = iris[, 1:4],
  method = "var_cah",
  K = 2,
  scale = TRUE
)

# Afficher le résumé
result$summary()

# Accéder aux groupes
print(result$Groupes)

## ----r6_usage-----------------------------------------------------------------
# Créer un objet VAR_CAH
model <- VAR_CAH$new(K = 2, scale = TRUE)

# Ajuster sur les données
model$fit(iris[, 1:4])

# Afficher le résumé
model$summary()

# Modifier le nombre de clusters
model$K <- 3

## ----iris_exploration---------------------------------------------------------
# Voir la structure des données
str(iris[, 1:4])

# Matrice de corrélation
cor(iris[, 1:4])

## ----iris_clustering----------------------------------------------------------
# Méthode 1 : VAR_CAH
model_cah <- roller_clust(iris[, 1:4], method = "var_cah", K = 2)
cat("\n=== VAR_CAH ===\n")
print(model_cah$Groupes)

# Méthode 2 : VARCLUS
model_vc <- roller_clust(iris[, 1:4], method = "varclus", K = 2)
cat("\n=== VARCLUS ===\n")
print(model_vc$Groupes)

## ----iris_comparison----------------------------------------------------------
# Comparer les affectations
comparison <- data.frame(
  Variable = names(iris[, 1:4]),
  VAR_CAH = model_cah$Groupes,
  VARCLUS = model_vc$Groupes
)
print(comparison)

## ----titanic_example----------------------------------------------------------
# Charger les données Titanic
data(Titanic)
titanic_df <- as.data.frame(Titanic)

# Utiliser K-modes pour les variables catégorielles
model_kmodes <- roller_clust(
  X = titanic_df[, c("Class", "Sex", "Age", "Survived")],
  method = "kmodes",
  K = 2
)

cat("FX est NULL?", is.null(model_kmodes$.__enclos_env__$private$FX), "\n")


model_kmodes$summary()
print(model_kmodes$Groupes)

## ----dynamic_k----------------------------------------------------------------
# Créer un modèle avec K=2
model <- VAR_CAH$new(K = 2)
model$fit(iris[, 1:4])

cat("Avec K=2:\n")
print(model$Groupes)

# Changer K (ré-ajuste automatiquement)
model$K <- 3

cat("\nAprès modification à K=3:\n")
print(model$Groupes)

## ----na_handling--------------------------------------------------------------
# Créer des données avec NA
iris_na <- iris[, 1:4]
iris_na[1:5, 1] <- NA

# Option 1 : Avertissement (défaut)
model_warn <- roller_clust(iris_na, na.action = "warn")

# Option 2 : Suppression des observations avec NA
model_omit <- roller_clust(iris_na, na.action = "omit")

# Option 3 : Arrêt si NA
# model_fail <- roller_clust(iris_na, na.action = "fail")  # Génère une erreur

## ----interpretation-----------------------------------------------------------
model <- VAR_CAH$new(K = 2)
model$fit(iris[, 1:4])

# Si on obtient :
# Cluster 1 : Sepal.Length, Sepal.Width
# Cluster 2 : Petal.Length, Petal.Width

# Interprétation : 
# - Le cluster 1 représente la dimension "Sépale"
# - Le cluster 2 représente la dimension "Pétale"

