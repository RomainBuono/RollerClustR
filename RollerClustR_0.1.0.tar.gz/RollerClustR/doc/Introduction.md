
# Introduction

## Qu’est-ce que la classification de variables ? ## 

Créer des groupes de variables de manière à rassembler les variables qui portent les mêmes 
informations (redondantes, corrélées), et dissocier les variables qui expriment  des 
informations complémentaires.